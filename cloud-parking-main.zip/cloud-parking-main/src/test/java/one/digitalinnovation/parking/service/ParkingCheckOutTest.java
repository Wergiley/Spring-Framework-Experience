package one.digitalinnovation.parking.service;

import org.junit.jupiter.api.Test;

class ParkingCheckOutTest {

    @Test
    void getBill() {

    }
}
